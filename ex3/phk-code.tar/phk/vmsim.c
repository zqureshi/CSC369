#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/queue.h>

#include "binheap.h"

/**********************************************************************
 * A simple minded  Virtual Memory Simulator
 */

struct vmp {
	unsigned		pgidx;
	uintptr_t		*p;
	TAILQ_ENTRY(vmp)	lru;
	unsigned		dirty;
	unsigned		in_core;
	unsigned		page_out;
	unsigned		page_ops;
};

static TAILQ_HEAD(,vmp)		vm_lru_head;
static TAILQ_HEAD(,vmp)		vm_po_head;
static unsigned 		vm_ncore;
static unsigned 		vm_psize;
static unsigned 		vm_nres;
static struct vmp		*vm_pidx[10000];

void
VM_init(unsigned ncore, unsigned psize)
{
	TAILQ_INIT(&vm_lru_head);
	TAILQ_INIT(&vm_po_head);
	vm_nres = 0;
	vm_ncore = ncore;
	vm_psize = psize;
	memset(vm_pidx, 0, sizeof vm_pidx);
}

static void
VM_pageout(void)
{
	struct vmp *po;

	po = TAILQ_FIRST(&vm_lru_head);
	assert(po != NULL);
	assert(po->in_core);
	po->in_core = 0;
	if (po->dirty)
		po->page_ops++;
	po->dirty = 0;
	TAILQ_REMOVE(&vm_lru_head, po, lru);
	TAILQ_INSERT_TAIL(&vm_po_head, po, lru);
	vm_nres--;
}

static struct vmp *
VM_getp(unsigned pgidx)
{
	struct vmp *p;

	p = vm_pidx[pgidx];
		
	if (p == NULL) {
		p = calloc(sizeof *p, 1);
		assert(p != NULL);
		p->p = calloc(sizeof(uintptr_t), vm_psize);
		assert(p->p != NULL);
		p->pgidx = pgidx;
		vm_pidx[pgidx] = p;
		TAILQ_INSERT_TAIL(&vm_po_head, p, lru);
	}

	if (!p->in_core) {
		if (vm_nres == vm_ncore) {
			VM_pageout();
			p->page_ops++;
		}
		assert(!p->dirty);
		p->in_core = 1;
		TAILQ_REMOVE(&vm_po_head, p, lru);
		vm_nres++;
		assert(vm_nres <= vm_ncore);
	} else {
		TAILQ_REMOVE(&vm_lru_head, p, lru);
	}
	TAILQ_INSERT_TAIL(&vm_lru_head, p, lru);
	return (p);
}

uintptr_t
VM_rd(unsigned pgidx, unsigned idx)
{
	struct vmp *p;

	assert(idx < vm_psize);
	p = VM_getp(pgidx);
	return (p->p[idx]);
}

void
VM_wr(unsigned pgidx, unsigned idx, uintptr_t val)
{
	struct vmp *p;

	assert(idx < vm_psize);
	p = VM_getp(pgidx);
	p->dirty = 1;
	p->p[idx] = val;
}

void
VM_finish(unsigned *npg, unsigned *npo)
{
	struct vmp *p, *p2;

	*npg = *npo = 0;
	TAILQ_FOREACH(p, &vm_lru_head, lru) {
		(*npg)++;
		*npo += p->page_ops;
		free(p->p);
		free(p);
	}
	TAILQ_FOREACH(p, &vm_po_head, lru) {
		(*npg)++;
		*npo += p->page_ops;
		free(p->p);
		free(p);
	}
}
